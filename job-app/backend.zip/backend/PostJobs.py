class JobDetails:
  def __init__(self, jobTitle, company, location, summary, date, applyURL, source):
    self.jobTitle = jobTitle
    self.company = company
    self.location = location
    self.summary = summary
    self.date = date
    self.applyURL = applyURL
    self.source = source

