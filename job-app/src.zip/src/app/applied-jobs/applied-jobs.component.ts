import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-applied-jobs',
  templateUrl: './applied-jobs.component.html',
  styleUrls: ['./applied-jobs.component.css']
})
export class AppliedJobsComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
      }

}
