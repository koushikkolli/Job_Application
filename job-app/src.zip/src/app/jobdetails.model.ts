export class JobDetails{
    constructor(public jobTitle: string, public company: string, public location: string,
        public summary: string, public date: string, public applySite:string,public source: string,
        public applyURL: string, public description: string, public additionalDetails: string, public keyWord: string){}
}