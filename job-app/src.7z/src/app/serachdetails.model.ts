export class SearchDetails{
    constructor(public keyWord: string, public where: string){}
}