#import pandas as pd
#__keywords__ = list(pd.read_csv(r"keywords.csv", header = None)[0])

__keywords__ = ["Academic","Administration","Allergy & Immunology","Anesthesiology"]
__locations__ = ["New York"]
